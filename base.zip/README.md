The site based on Django for selling subscriptions to use the Order Manager service generates order files from original images according to the provided list of items.


*Site for Order Manager (WB 2.1.1)*
====
Order Manager for WB
----
>
> The site based on Django for selling subscriptions 
> to use the Order Manager service generates order 
> files from original images according to the provided 
> list of items.
>
>> author: SeriouS 
>
>> email: onium16@gmail.com